import React from "react";
import { WelcomeBanner } from "../../components/partials";

export const Dashboard = () => {
    return (
        <>
            <WelcomeBanner />
            Dashboard
        </>
    );
};
