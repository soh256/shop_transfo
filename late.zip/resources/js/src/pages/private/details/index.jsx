export * from "./CustomerDetail";
export * from "./ProductDetail";
export * from "./OrderDetail";
