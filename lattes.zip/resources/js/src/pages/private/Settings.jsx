import React from "react";

export const Settings = () => {
    return <>Settings</>;
};
